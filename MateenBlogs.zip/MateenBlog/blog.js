// Set current year in footer
document.getElementById('year').textContent = new Date().getFullYear();
 
// Back to top button
const backToTop = document.querySelector('.back-to-top');
window.addEventListener('scroll', () => {
  backToTop.classList.toggle('visible', window.scrollY > 300);
});

function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Dropdown functionality
document.querySelectorAll('.dropdown-header').forEach(header => {
  header.addEventListener('click', () => {
    const content = header.nextElementSibling;
    content.classList.toggle('show');
    header.setAttribute('aria-expanded', content.classList.contains('show'));
  });
});

// Theme toggle
const themeToggle = document.getElementById('theme-toggle');
themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark-mode');
  const icon = themeToggle.querySelector('i');
  if (document.body.classList.contains('dark-mode')) {
    icon.classList.replace('fa-moon', 'fa-sun');
  } else {
    icon.classList.replace('fa-sun', 'fa-moon');
  }
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    e.preventDefault();
    document.querySelector(this.getAttribute('href')).scrollIntoView({
      behavior: 'smooth'
    });
  });
});

function searchContent() {
  const searchTerm = document.getElementById('search-input').value.toLowerCase();
  const dropdowns = document.querySelectorAll('.dropdown');

  dropdowns.forEach(dropdown => {
    const header = dropdown.querySelector('.dropdown-header').textContent.toLowerCase();
    const content = dropdown.querySelector('.dropdown-content').textContent.toLowerCase();
    if (header.includes(searchTerm) || content.includes(searchTerm)) {
      dropdown.style.display = 'block';
    } else {
      dropdown.style.display = 'none';
    }
  });
}